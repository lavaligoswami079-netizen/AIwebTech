﻿const http = require("http");
const https = require("https");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  fs.readFileSync(envPath, "utf8")
    .split(/\r?\n/)
    .filter((line) => line && !line.trim().startsWith("#") && line.includes("="))
    .forEach((line) => {
      const [key, ...rest] = line.split("=");
      if (!process.env[key]) process.env[key] = rest.join("=").trim();
    });
}

let OAuth2Client = null;
try { OAuth2Client = require("google-auth-library").OAuth2Client; } catch {}

const PORT = process.env.PORT || 5000;
const MYSQL_HOST = process.env.MYSQL_HOST || "localhost";
const MYSQL_USER = process.env.MYSQL_USER || "root";
const MYSQL_PASSWORD = process.env.MYSQL_PASSWORD || "";
const MYSQL_DATABASE = process.env.MYSQL_DATABASE || "aiwebtech";
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "";
const JWT_SECRET = process.env.JWT_SECRET || "change-this-secret";
const ADMIN_KEY = process.env.ADMIN_KEY || "admin-demo-key";
const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || "";
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || "";
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "*";
const NODE_ENV = process.env.NODE_ENV || "development";

let pool = null;
try {
  const mysql = require("mysql2/promise");
  pool = mysql.createPool({
    host: MYSQL_HOST,
    user: MYSQL_USER,
    password: MYSQL_PASSWORD,
    database: MYSQL_DATABASE,
    waitForConnections: true,
    connectionLimit: 10,
  });
} catch (error) {
  console.warn("mysql2 is not installed yet. Run npm install in backend folder.");
}

const memory = { users: [], contacts: [], orders: [], websites: [], requests: [] };

const templates = [
  { id: "agency-pro", name: "Agency Pro", sector: "Business", price: 29, page: "templates/agency-pro.html" },
  { id: "smart-store", name: "Smart Store", sector: "Ecommerce", price: 39, page: "templates/smart-store.html" },
  { id: "restaurant-menu", name: "Restaurant Menu", sector: "Food", price: 34, page: "templates/restaurant-menu.html" },
  { id: "edu-academy", name: "Edu Academy", sector: "Education", price: 31, page: "templates/edu-academy.html" },
  { id: "health-clinic", name: "Health Clinic", sector: "Health", price: 36, page: "templates/health-clinic.html" },
  { id: "real-estate", name: "Real Estate", sector: "Property", price: 42, page: "templates/real-estate.html" },
  { id: "creator-folio", name: "Creator Folio", sector: "Creative", price: 19, page: "templates/creator-folio.html" },
  { id: "travel-guide", name: "Travel Guide", sector: "Travel", price: 33, page: "templates/travel-guide.html" },
  { id: "beauty-studio", name: "Beauty Studio", sector: "Beauty", price: 28, page: "templates/beauty-studio.html" },
  { id: "tech-startup", name: "Tech Startup", sector: "Technology", price: 45, page: "templates/tech-startup.html" },
  { id: "nonprofit-cause", name: "Nonprofit Cause", sector: "Nonprofit", price: 24, page: "templates/nonprofit-cause.html" },
  { id: "event-launch", name: "Event Launch", sector: "Events", price: 27, page: "templates/event-launch.html" },
];

const plans = [
  { id: "starter", name: "Starter", price: 9, features: ["1 website template", "Basic AI help", "Email support"] },
  { id: "growth", name: "Growth", price: 29, features: ["5 premium templates", "AI website copy ideas", "Priority support"] },
  { id: "business", name: "Business", price: 79, features: ["Unlimited templates", "Custom AI assistant", "Setup guidance"] },
];

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": FRONTEND_ORIGIN,
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, x-admin-key",
    "Vary": "Origin",
    "X-Content-Type-Options": "nosniff",
  });
  res.end(JSON.stringify(data));
}

function collectBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) req.destroy();
    });
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); } catch (error) { reject(error); }
    });
  });
}

function hashPassword(password = "") {
  return crypto.createHash("sha256").update(`${password}:${JWT_SECRET}`).digest("hex");
}

function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    firstName: user.first_name || user.firstName,
    middleName: user.middle_name || user.middleName,
    lastName: user.last_name || user.lastName,
    dob: user.dob,
    email: user.email,
    phone: user.phone,
    permanentAddress: user.permanent_address || user.permanentAddress,
    currentAddress: user.current_address || user.currentAddress,
    provider: user.provider || "email",
    isAdmin: Boolean(user.is_admin || user.isAdmin),
  };
}

function signToken(user) {
  const payload = Buffer.from(JSON.stringify({ id: user.id, email: user.email, isAdmin: Boolean(user.is_admin || user.isAdmin), ts: Date.now() })).toString("base64url");
  const signature = crypto.createHmac("sha256", JWT_SECRET).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function verifyToken(token = "") {
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return null;
  const expected = crypto.createHmac("sha256", JWT_SECRET).update(payload).digest("base64url");
  if (signature !== expected) return null;
  try { return JSON.parse(Buffer.from(payload, "base64url").toString("utf8")); } catch { return null; }
}

function authPayload(req) {
  const auth = req.headers.authorization || "";
  return verifyToken(auth.replace("Bearer ", ""));
}

async function query(sql, params = []) {
  if (!pool) return null;
  const [rows] = await pool.execute(sql, params);
  return rows;
}

async function findUserByEmail(email) {
  if (!email) return null;
  if (pool) {
    const rows = await query("SELECT * FROM users WHERE email = ? LIMIT 1", [email]);
    if (rows) return rows[0];
  }
  return memory.users.find((user) => user.email === email) || null;
}

async function createUser(data, provider = "email") {
  const user = {
    firstName: data.firstName || data.given_name || "",
    middleName: data.middleName || "",
    lastName: data.lastName || data.family_name || "",
    dob: data.dob || null,
    email: data.email,
    phone: data.phone || "",
    permanentAddress: data.permanentAddress || "",
    currentAddress: data.currentAddress || "",
    passwordHash: provider === "email" ? hashPassword(data.password) : "",
    provider,
    googleId: data.googleId || data.sub || null,
  };

  if (pool) {
    const result = await query(
      "INSERT INTO users (first_name, middle_name, last_name, dob, email, phone, permanent_address, current_address, password_hash, provider, google_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [user.firstName, user.middleName, user.lastName, user.dob, user.email, user.phone, user.permanentAddress, user.currentAddress, user.passwordHash, user.provider, user.googleId]
    );
    if (result) return { ...user, id: result.insertId };
  }

  const existing = memory.users.find((item) => item.email === user.email);
  if (existing) return existing;
  const memoryUser = { ...user, id: Date.now() };
  memory.users.push(memoryUser);
  return memoryUser;
}

async function upsertGoogleUser(profile) {
  const existing = await findUserByEmail(profile.email);
  if (existing) return existing;
  return createUser({ ...profile, firstName: profile.given_name, lastName: profile.family_name, googleId: profile.sub }, "google");
}

async function decodeGoogleCredential(credential) {
  if (!credential) return null;
  if (OAuth2Client && GOOGLE_CLIENT_ID) {
    const client = new OAuth2Client(GOOGLE_CLIENT_ID);
    const ticket = await client.verifyIdToken({ idToken: credential, audience: GOOGLE_CLIENT_ID });
    return ticket.getPayload();
  }
  const payload = credential.split(".")[1];
  if (!payload) return null;
  return JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
}

async function isAdmin(req) {
  if ((req.headers["x-admin-key"] || "") === ADMIN_KEY) return true;
  const payload = authPayload(req);
  if (!payload?.email) return false;
  const user = await findUserByEmail(payload.email);
  return Boolean(user?.is_admin || user?.isAdmin);
}

async function initializeDatabase() {
  if (!pool) return;
  try {
    await query("ALTER TABLE users ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0");
  } catch (error) {
    if (!String(error.message || "").toLowerCase().includes("duplicate column")) {
      console.warn("Could not add admin column:", error.message);
    }
  }
}

function createRazorpayOrder({ amount, currency = "INR", receipt, notes = {} }) {
  return new Promise((resolve, reject) => {
    if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
      resolve({ id: `order_demo_${Date.now()}`, amount, currency, receipt, status: "created", demo: true, key: "" });
      return;
    }
    const body = JSON.stringify({ amount, currency, receipt, notes });
    const auth = Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString("base64");
    const req = https.request({
      hostname: "api.razorpay.com",
      path: "/v1/orders",
      method: "POST",
      headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
    }, (res) => {
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => {
        try {
          const parsed = JSON.parse(data || "{}");
          if (res.statusCode >= 400) reject(new Error(parsed.error?.description || "Razorpay order failed"));
          else resolve({ ...parsed, key: RAZORPAY_KEY_ID });
        } catch (error) { reject(error); }
      });
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

async function requireUser(req, res) {
  const payload = authPayload(req);
  if (!payload?.email) {
    sendJson(res, 401, { ok: false, message: "Login required." });
    return null;
  }
  const user = await findUserByEmail(payload.email);
  if (!user) {
    sendJson(res, 401, { ok: false, message: "User not found." });
    return null;
  }
  return user;
}

function aiReply(message = "") {
  const text = message.toLowerCase();
  if (text.includes("price") || text.includes("plan")) return "Starter is good for testing. Growth is best for selling templates. Business is best for custom AI and bigger clients.";
  if (text.includes("shop") || text.includes("store")) return "Smart Store is the best template for ecommerce, product pages, offers, and checkout-ready sections.";
  if (text.includes("school") || text.includes("course") || text.includes("education")) return "Edu Academy is a strong choice for schools, tutors, coaching, courses, and institutes.";
  if (text.includes("doctor") || text.includes("clinic") || text.includes("health")) return "Health Clinic is made for doctors, clinics, dentists, therapists, and appointment booking.";
  return "Tell me the business sector, and Tace AI will suggest the best template and plan.";
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return sendJson(res, 200, { ok: true });
  if (NODE_ENV === "production" && (JWT_SECRET === "change-this-secret" || ADMIN_KEY === "admin-demo-key")) {
    console.warn("Production warning: change JWT_SECRET and ADMIN_KEY in .env.");
  }

  try {
    if (req.method === "GET" && req.url === "/api/health") return sendJson(res, 200, { ok: true, app: "AIwebTech backend", mysql: Boolean(pool) });
    if (req.method === "GET" && req.url === "/api/templates") return sendJson(res, 200, templates);
    if (req.method === "GET" && req.url === "/api/plans") return sendJson(res, 200, plans);


    if (req.method === "GET" && req.url === "/api/public-config") {
      return sendJson(res, 200, { ok: true, razorpayKeyId: RAZORPAY_KEY_ID, googleClientId: GOOGLE_CLIENT_ID });
    }

    if (req.method === "POST" && req.url === "/api/razorpay-order") {
      const user = await requireUser(req, res); if (!user) return;
      const data = await collectBody(req);
      const amountPaise = Math.round(Number(data.amount || 0) * 100);
      if (!amountPaise) return sendJson(res, 400, { ok: false, message: "Amount is required." });
      const order = await createRazorpayOrder({ amount: amountPaise, currency: data.currency || "INR", receipt: `receipt_${Date.now()}`, notes: { template: data.template || "Website", user: user.email } });
      return sendJson(res, 201, { ok: true, order });
    }

    if (req.method === "GET" && req.url === "/api/admin/summary") {
      if (!(await isAdmin(req))) return sendJson(res, 403, { ok: false, message: "Admin login required." });
      if (pool) {
        const users = await query("SELECT COUNT(*) AS count FROM users");
        const orders = await query("SELECT COUNT(*) AS count FROM orders");
        const requests = await query("SELECT COUNT(*) AS count FROM website_requests");
        const websites = await query("SELECT COUNT(*) AS count FROM websites");
        if (users && orders && requests && websites) return sendJson(res, 200, { ok: true, users: users[0].count, orders: orders[0].count, requests: requests[0].count, websites: websites[0].count });
      }
      return sendJson(res, 200, { ok: true, users: memory.users.length, orders: memory.orders.length, requests: memory.requests.length, websites: memory.websites.length });
    }

    if (req.method === "GET" && req.url === "/api/admin/orders") {
      if (!(await isAdmin(req))) return sendJson(res, 403, { ok: false, message: "Admin login required." });
      if (pool) {
        const rows = await query("SELECT order_code, template_name, amount, currency, payment_status, created_at FROM orders ORDER BY created_at DESC LIMIT 100");
        if (rows) return sendJson(res, 200, { ok: true, orders: rows });
      }
      return sendJson(res, 200, { ok: true, orders: memory.orders });
    }

    if (req.method === "GET" && req.url === "/api/admin/requests") {
      if (!(await isAdmin(req))) return sendJson(res, 403, { ok: false, message: "Admin login required." });
      if (pool) {
        const rows = await query("SELECT business_name, website_type, budget, status, created_at FROM website_requests ORDER BY created_at DESC LIMIT 100");
        if (rows) return sendJson(res, 200, { ok: true, requests: rows });
      }
      return sendJson(res, 200, { ok: true, requests: memory.requests });
    }
    if (req.method === "POST" && req.url === "/api/register") {
      const data = await collectBody(req);
      if (!data.email || !data.firstName || !data.lastName || !data.password) return sendJson(res, 400, { ok: false, message: "First name, last name, email, and password are required." });
      if (await findUserByEmail(data.email)) return sendJson(res, 409, { ok: false, message: "Email already exists. Please login." });
      const user = await createUser(data, "email");
      return sendJson(res, 201, { ok: true, message: "Account created.", token: signToken(user), user: publicUser(user) });
    }

    if (req.method === "POST" && req.url === "/api/login") {
      const data = await collectBody(req);
      const user = await findUserByEmail(data.email);
      if (!user || (user.password_hash || user.passwordHash) !== hashPassword(data.password)) return sendJson(res, 401, { ok: false, message: "Invalid email or password." });
      return sendJson(res, 200, { ok: true, message: "Login successful.", token: signToken(user), user: publicUser(user) });
    }

    if (req.method === "POST" && req.url === "/api/google-login") {
      const data = await collectBody(req);
      const profile = await decodeGoogleCredential(data.credential);
      if (!profile?.email) return sendJson(res, 400, { ok: false, message: "Google credential missing. Add a valid Google Client ID." });
      if (GOOGLE_CLIENT_ID && profile.aud !== GOOGLE_CLIENT_ID) return sendJson(res, 401, { ok: false, message: "Google client ID does not match." });
      const user = await upsertGoogleUser(profile);
      return sendJson(res, 200, { ok: true, message: "Google login successful.", token: signToken(user), user: publicUser(user) });
    }

    if (req.method === "POST" && req.url === "/api/website-requests") {
      const user = await requireUser(req, res); if (!user) return;
      const data = await collectBody(req);
      if (pool) {
        await query("INSERT INTO website_requests (user_id, business_name, website_type, description, features, budget, deadline) VALUES (?, ?, ?, ?, ?, ?, ?)", [user.id, data.businessName, data.websiteType, data.description, data.features, data.budget, data.deadline || null]);
      } else {
        memory.requests.push({ ...data, userId: user.id, id: Date.now() });
      }
      return sendJson(res, 201, { ok: true, message: "Website request saved." });
    }

    if (req.method === "POST" && req.url === "/api/create-payment") {
      const body = await collectBody(req);
      const user = authPayload(req)?.email ? await findUserByEmail(authPayload(req).email) : await findUserByEmail(body.user?.email);
      if (!user || !body.template || !body.amount) return sendJson(res, 400, { ok: false, message: "User, template, and amount are required." });
      const template = templates.find((item) => item.name === body.template) || templates[0];
      const orderId = `AWebT-${Date.now()}`;
            let savedToMysql = false;
      if (pool) {
        const result = await query("INSERT INTO orders (order_code, user_id, template_name, amount, currency, payment_method, gateway_order_id, gateway_payment_id, card_last4, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [orderId, user.id, body.template, body.amount, body.currency || "USD", body.paymentMethod || "Demo Gateway", body.razorpayOrderId || "", body.razorpayPaymentId || "", body.cardLast4 || "", "paid_demo"]);
        if (result) {
          await query("INSERT INTO websites (user_id, order_id, template_name, page, status, domain) VALUES (?, ?, ?, ?, ?, ?)", [user.id, result.insertId, body.template, template.page, "active", "Pending domain"]);
          savedToMysql = true;
        }
      }
      if (!savedToMysql) {
        const order = { id: orderId, userEmail: user.email, template: body.template, amount: body.amount, status: "paid_demo", createdAt: new Date().toISOString() };
        memory.orders.push(order);
        memory.websites.push({ id: Date.now(), userEmail: user.email, template_name: body.template, page: template.page, status: "active", domain: "Pending domain", createdAt: order.createdAt });
      }
      return sendJson(res, 201, { ok: true, message: "Demo payment successful.", order: { id: orderId, status: "paid_demo" } });
    }

    if (req.method === "GET" && req.url === "/api/my-websites") {
      const user = await requireUser(req, res); if (!user) return;
            if (pool) {
        const websites = await query("SELECT template_name, page, status, domain, DATE_FORMAT(created_at, '%Y-%m-%d') AS created_at FROM websites WHERE user_id = ? ORDER BY created_at DESC", [user.id]);
        if (websites) return sendJson(res, 200, { ok: true, websites });
      }
      return sendJson(res, 200, { ok: true, websites: memory.websites.filter((site) => site.userEmail === user.email) });
    }

    if (req.method === "GET" && req.url === "/api/orders") {
      if (pool) return sendJson(res, 200, await query("SELECT * FROM orders ORDER BY created_at DESC"));
      return sendJson(res, 200, memory.orders);
    }

    if (req.method === "POST" && req.url === "/api/contact") {
      const data = await collectBody(req);
      memory.contacts.push({ ...data, id: Date.now(), createdAt: new Date().toISOString() });
      return sendJson(res, 201, { ok: true, message: "Contact request saved." });
    }

    if (req.method === "POST" && req.url === "/api/ai-chat") {
      const data = await collectBody(req);
      return sendJson(res, 200, { reply: aiReply(data.message) });
    }

    sendJson(res, 404, { ok: false, message: "API route not found." });
  } catch (error) {
    sendJson(res, 500, { ok: false, message: error.message || "Server error." });
  }
});

initializeDatabase().finally(() => {
  server.listen(PORT, () => console.log(`AIwebTech backend running at http://localhost:${PORT}`));
});








