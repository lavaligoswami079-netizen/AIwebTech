const API_BASE = window.AIWEBTECH_CONFIG?.API_BASE || "http://localhost:5000";
const form = document.querySelector("#adminLoginForm");
const statusBox = document.querySelector("#status");

function setStatus(text, type = "success") {
  statusBox.textContent = text;
  statusBox.className = `status ${type}`;
}

function formData(formElement) {
  return Object.fromEntries(new FormData(formElement).entries());
}

async function loginAdmin() {
  const res = await fetch(`${API_BASE}/api/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(formData(form)),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Admin login failed.");
  if (!data.user?.isAdmin) throw new Error("This account is not admin. Mark this user as admin in MySQL first.");
  localStorage.setItem("aiwebtech_admin_token", data.token);
  return data.token;
}

async function adminApi(path, token) {
  const res = await fetch(`${API_BASE}${path}`, { headers: { Authorization: `Bearer ${token}` } });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Admin request failed.");
  return data;
}

function row(value) {
  return value == null || value === "" ? "-" : value;
}

function renderAdminData(summary, orders, requests) {
  document.querySelector("#adminSummary").innerHTML = `<article class="card"><h3>Users</h3><p>${summary.users}</p></article><article class="card"><h3>Orders</h3><p>${summary.orders}</p></article><article class="card"><h3>Requests</h3><p>${summary.requests}</p></article>`;
  document.querySelector("#ordersTable tbody").innerHTML = (orders.orders || []).map((order) => `<tr><td>${row(order.order_code || order.id)}</td><td>${row(order.template_name || order.template)}</td><td>${row(order.amount)} ${row(order.currency || "")}</td><td><span class="badge">${row(order.payment_status || order.status)}</span></td><td>${row(order.created_at || order.createdAt)}</td></tr>`).join("") || `<tr><td colspan="5">No orders yet.</td></tr>`;
  document.querySelector("#requestsTable tbody").innerHTML = (requests.requests || []).map((request) => `<tr><td>${row(request.business_name || request.businessName)}</td><td>${row(request.website_type || request.websiteType)}</td><td>${row(request.budget)}</td><td><span class="badge">${row(request.status || "new")}</span></td><td>${row(request.created_at || request.createdAt)}</td></tr>`).join("") || `<tr><td colspan="5">No requests yet.</td></tr>`;
}

async function loadAdminData(token) {
  const [summary, orders, requests] = await Promise.all([
    adminApi("/api/admin/summary", token),
    adminApi("/api/admin/orders", token),
    adminApi("/api/admin/requests", token),
  ]);
  renderAdminData(summary, orders, requests);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const token = await loginAdmin();
    await loadAdminData(token);
    setStatus("Admin login successful. Admin data loaded.");
  } catch (error) {
    setStatus(error.message, "error");
  }
});
