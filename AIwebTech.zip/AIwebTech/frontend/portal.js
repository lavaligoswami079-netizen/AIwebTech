﻿const API_BASE = window.AIWEBTECH_CONFIG?.API_BASE || "http://localhost:5000";
const statusBox = document.querySelector("#status");

function setStatus(text, type = "success") {
  if (!statusBox) return;
  statusBox.textContent = text;
  statusBox.className = `status ${type}`;
}

function formData(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function saveSession(data) {
  localStorage.setItem("aiwebtechSession", JSON.stringify(data));
}

function getSession() {
  try { return JSON.parse(localStorage.getItem("aiwebtechSession") || "null"); } catch { return null; }
}

async function api(path, options = {}) {
  const session = getSession();
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (session?.token) headers.Authorization = `Bearer ${session.token}`;
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Request failed");
  return data;
}

const loginForm = document.querySelector("#loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const result = await api("/api/login", { method: "POST", body: JSON.stringify(formData(loginForm)) });
      saveSession(result);
      setStatus("Login successful. Opening dashboard...");
      setTimeout(() => location.href = "dashboard.html", 500);
    } catch (error) {
      setStatus(error.message, "error");
    }
  });
}

const signupForm = document.querySelector("#signupForm");
if (signupForm) {
  signupForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const result = await api("/api/register", { method: "POST", body: JSON.stringify(formData(signupForm)) });
      saveSession(result);
      setStatus("Account created. Opening dashboard...");
      setTimeout(() => location.href = "dashboard.html", 500);
    } catch (error) {
      setStatus(error.message, "error");
    }
  });
}

window.handleGoogleCredential = async (response) => {
  try {
    const result = await api("/api/google-login", { method: "POST", body: JSON.stringify({ credential: response.credential }) });
    saveSession(result);
    location.href = "dashboard.html";
  } catch (error) {
    setStatus("Google sign-in needs backend setup and a Google Client ID.", "error");
  }
};

const requestForm = document.querySelector("#websiteRequestForm");
if (requestForm) {
  requestForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await api("/api/website-requests", { method: "POST", body: JSON.stringify(formData(requestForm)) });
      setStatus("Website request sent. It will appear in your dashboard.");
      requestForm.reset();
    } catch (error) {
      setStatus(error.message, "error");
    }
  });
}

const logout = document.querySelector("#logoutBtn");
if (logout) {
  logout.addEventListener("click", () => {
    localStorage.removeItem("aiwebtechSession");
    location.href = "login.html";
  });
}

async function loadDashboard() {
  const table = document.querySelector("#sitesTable");
  const userName = document.querySelector("#userName");
  if (!table) return;
  const session = getSession();
  if (!session?.token) {
    location.href = "login.html";
    return;
  }
  if (userName) userName.textContent = session.user?.firstName || session.user?.email || "User";
  try {
    const data = await api("/api/my-websites");
    const rows = data.websites.map((site) => `
      <tr>
        <td>${site.template_name || site.template || "Website"}</td>
        <td><span class="badge">${site.status || "active"}</span></td>
        <td>${site.domain || "Pending domain"}</td>
        <td>${site.created_at || site.createdAt || "Today"}</td>
        <td><a class="btn secondary" href="${site.page || "templates/index.html"}">Open website</a></td>
      </tr>`).join("");
    table.querySelector("tbody").innerHTML = rows || `<tr><td colspan="5">No websites yet. Request or buy a website to see it here.</td></tr>`;
  } catch (error) {
    table.querySelector("tbody").innerHTML = `<tr><td colspan="5">Start backend and MySQL to load your websites.</td></tr>`;
  }
}
loadDashboard();

