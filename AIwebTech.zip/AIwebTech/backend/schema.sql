﻿CREATE DATABASE IF NOT EXISTS aiwebtech;
USE aiwebtech;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  middle_name VARCHAR(100),
  last_name VARCHAR(100) NOT NULL,
  dob DATE,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(40),
  permanent_address TEXT,
  current_address TEXT,
  password_hash VARCHAR(255),
  provider ENUM('email','google') DEFAULT 'email',
  google_id VARCHAR(190),
  is_admin TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS website_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  business_name VARCHAR(190),
  website_type VARCHAR(120),
  description TEXT,
  features TEXT,
  budget VARCHAR(80),
  deadline DATE,
  status VARCHAR(60) DEFAULT 'new',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_code VARCHAR(80) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  template_name VARCHAR(160) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  currency VARCHAR(10) DEFAULT 'USD',
  payment_method VARCHAR(80),
    gateway_order_id VARCHAR(120),
  gateway_payment_id VARCHAR(120),
  card_last4 VARCHAR(8),
  payment_status VARCHAR(60) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS websites (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  order_id INT,
  template_name VARCHAR(160) NOT NULL,
  page VARCHAR(255),
  status VARCHAR(60) DEFAULT 'active',
  domain VARCHAR(190) DEFAULT 'Pending domain',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
);


