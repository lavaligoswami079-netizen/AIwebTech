USE aiwebtech;

-- First signup normally on signup.html, then replace this email with your own login email.
UPDATE users
SET is_admin = 1
WHERE email = 'your-email@example.com';

SELECT id, email, is_admin
FROM users
WHERE email = 'your-email@example.com';
