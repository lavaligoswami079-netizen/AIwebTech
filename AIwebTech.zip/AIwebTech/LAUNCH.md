﻿# AIwebTech Launch Guide

Your project is now structured for launch.

## 1. Frontend

Host the `frontend` folder on Netlify, Vercel static hosting, Hostinger static hosting, or any normal web host.

Before uploading, edit:

```text
frontend/config.js
```

Change:

```js
API_BASE: "http://localhost:5000"
```

to your deployed backend URL, for example:

```js
API_BASE: "https://api.yourdomain.com"
```

## 2. Backend

Host the `backend` folder on Render, Railway, VPS, Hostinger Node hosting, or any Node.js server.

Required production env values are listed in:

```text
backend/.env.production.example
```

Never upload real `.env` secrets to public GitHub.

## 3. MySQL

Create database tables:

```bash
mysql -u USER -p DATABASE_NAME < backend/schema.sql
```

Then set the MySQL values in your backend host environment.

## 4. Google Login

In Google Cloud Console, add your live frontend domain to Authorized JavaScript origins:

```text
https://yourdomain.com
```

Set the same client ID in:

```text
frontend/login.html
frontend/signup.html
backend environment GOOGLE_CLIENT_ID
```

## 5. Razorpay

Use Razorpay live keys only after account/KYC activation.

Set:

```text
RAZORPAY_KEY_ID=rzp_live_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
```

## 6. Final Test

Test these flows after deployment:

- Signup with email
- Login with email
- Google login
- Request custom website
- Open a template demo
- Buy a website
- See purchased website in dashboard
- Admin dashboard with your admin key

## 7. Important Security

Before launch, change:

```text
JWT_SECRET
ADMIN_KEY
FRONTEND_ORIGIN
```

Do not keep demo values in production.
