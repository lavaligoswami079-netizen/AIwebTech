﻿# AIwebTech Production Setup

## 1. MySQL

Run this once in MySQL:

```bash
mysql -u root -p < D:\Project\AIwebTech\backend\schema.sql
```

Create `D:\Project\AIwebTech\backend\.env` from `.env.example` and set:

```text
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=your_mysql_password
MYSQL_DATABASE=aiwebtech
JWT_SECRET=make-this-long-and-private
ADMIN_KEY=choose-your-admin-key
```

## 2. Razorpay

Create Razorpay keys from the Razorpay dashboard and set:

```text
RAZORPAY_KEY_ID=rzp_test_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
```

The backend creates Razorpay Orders using amount in the smallest currency unit, as Razorpay requires. If keys are missing, the app uses demo payment mode.

## 3. Google Login

Create a Google OAuth Web Client ID in Google Cloud Console and set:

```text
GOOGLE_CLIENT_ID=YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com
```

Then replace the same placeholder in:

```text
frontend/login.html
frontend/signup.html
```

Chrome saved passwords cannot be read by any website. Google Sign-In/OAuth is the correct secure method.

## 4. Admin Dashboard

Open:

```text
frontend/admin.html
```

Use the same `ADMIN_KEY` value from `.env`.

## 5. Run

Backend:

```bash
cd D:\Project\AIwebTech\backend
npm install
npm start
```

Frontend:

Open `D:\Project\AIwebTech\frontend` with VS Code Live Server.
