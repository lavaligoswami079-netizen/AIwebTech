﻿# AIwebTech Frontend

This folder contains the visible website code.

## Important files

- `index.html` - main home page
- `styles.css` - main website design
- `script.js` - template filters, buttons, and Tace AI frontend logic
- `templates/` - all separate template preview pages

## How to run

Open this `frontend` folder in VS Code and use the Live Server extension on `index.html`.

You can also open `index.html` directly in a browser, but Live Server is better.
