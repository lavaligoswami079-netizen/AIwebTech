﻿# AIwebTech Backend

This backend stores users, Google sign-in profiles, custom website requests, demo payment orders, and purchased websites in MySQL.

## Setup

1. Install packages:

```bash
cd D:\Project\AIwebTech\backend
npm install
```

2. Create MySQL database and tables:

```bash
mysql -u root -p < schema.sql
```

3. Set environment variables. Use `.env.example` as a guide. If you use PowerShell:

```powershell
$env:MYSQL_HOST="localhost"
$env:MYSQL_USER="root"
$env:MYSQL_PASSWORD="your_mysql_password"
$env:MYSQL_DATABASE="aiwebtech"
$env:JWT_SECRET="change-this-long-secret"
$env:GOOGLE_CLIENT_ID="YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com"
npm start
```

## Routes

- `POST /api/register`
- `POST /api/login`
- `POST /api/google-login`
- `POST /api/website-requests`
- `POST /api/create-payment`
- `GET /api/my-websites`
- `GET /api/orders`

Google Chrome saved passwords cannot be read by a website. Use Google Sign-In/OAuth instead.
