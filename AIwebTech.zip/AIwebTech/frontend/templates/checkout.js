﻿const API_BASE = window.AIWEBTECH_CONFIG?.API_BASE || "http://localhost:5000";

const templateName = document.body.dataset.template || document.title.replace(" Website Demo - Ai web tace", "");
const templatePrice = document.body.dataset.price || "39";
const userPanel = document.querySelector("#userPanel");
const checkoutForm = document.querySelector("#checkoutForm");
const authForm = document.querySelector("#authForm");
const checkoutTemplate = document.querySelector("#checkoutTemplate");
const checkoutAmount = document.querySelector("#checkoutAmount");
const authStatus = document.querySelector("#authStatus");
const paymentStatus = document.querySelector("#paymentStatus");

if (checkoutTemplate) checkoutTemplate.value = templateName;
if (checkoutAmount) checkoutAmount.value = `$${templatePrice}`;

function showStatus(element, text, type = "success") {
  if (!element) return;
  element.textContent = text;
  element.className = `panel-status ${type}`;
}

function getSession() {
  try { return JSON.parse(localStorage.getItem("aiwebtechSession") || "null"); } catch { return null; }
}

function saveSession(data) {
  localStorage.setItem("aiwebtechSession", JSON.stringify(data));
  if (data.user) localStorage.setItem("aiwebtechUser", JSON.stringify(data.user));
}

function loadUser() {
  const session = getSession();
  if (session?.user) return session.user;
  try { return JSON.parse(localStorage.getItem("aiwebtechUser") || "null"); } catch { return null; }
}

function getAuthData() {
  return Object.fromEntries(new FormData(authForm).entries());
}

async function api(path, payload, method = "POST") {
  const session = getSession();
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...(session?.token ? { Authorization: `Bearer ${session.token}` } : {}) },
    body: method === "GET" ? undefined : JSON.stringify(payload || {}),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Request failed");
  return data;
}

function fillUserFromStorage() {
  const user = loadUser();
  if (!user || !authForm) return;
  Object.entries(user).forEach(([key, value]) => {
    const field = authForm.elements[key];
    if (field) field.value = value || "";
  });
  showStatus(authStatus, `Welcome back, ${user.firstName || user.email || "customer"}.`);
}

if (authForm) {
  fillUserFromStorage();
  authForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const action = event.submitter?.dataset.action || "register";
    const payload = getAuthData();
    if (!payload.email || !payload.password) return showStatus(authStatus, "Please enter email and password.", "error");
    if (action === "register" && (!payload.firstName || !payload.lastName)) return showStatus(authStatus, "Please enter first and last name for signup.", "error");
    try {
      const result = await api(action === "login" ? "/api/login" : "/api/register", payload);
      saveSession(result);
      showStatus(authStatus, action === "login" ? "Login successful. You can buy now." : "Account created. You can buy now.");
    } catch (error) {
      showStatus(authStatus, error.message, "error");
    }
  });
}

function paymentPayload(payment = {}) {
  const user = loadUser() || getAuthData();
  return {
    template: templateName,
    amount: Number(templatePrice),
    currency: "INR",
    user,
    paymentMethod: payment.paymentMethod || "Demo Gateway",
    cardName: payment.cardName,
    cardLast4: (payment.cardNumber || payment.cardLast4 || "").replace(/\s/g, "").slice(-4),
  };
}

async function completePayment(payload) {
  const result = await api("/api/create-payment", payload);
  showStatus(paymentStatus, `${result.message} Order ID: ${result.order.id}. Opening dashboard...`);
  window.setTimeout(() => { window.location.href = "../dashboard.html"; }, 900);
}

async function startRazorpay(payload) {
  const orderResponse = await api("/api/razorpay-order", { template: templateName, amount: payload.amount, currency: "INR" });
  const order = orderResponse.order;
  if (order.demo || !window.Razorpay || !order.key) {
    await completePayment({ ...payload, paymentMethod: "Razorpay Demo", cardLast4: "demo" });
    return;
  }
  const razorpay = new window.Razorpay({
    key: order.key,
    amount: order.amount,
    currency: order.currency,
    name: "Ai web tace",
    description: `${templateName} website purchase`,
    order_id: order.id,
    handler: async (response) => {
      await completePayment({ ...payload, paymentMethod: "Razorpay", razorpayPaymentId: response.razorpay_payment_id, razorpayOrderId: response.razorpay_order_id });
    },
    prefill: { name: `${payload.user.firstName || ""} ${payload.user.lastName || ""}`.trim(), email: payload.user.email, contact: payload.user.phone },
    theme: { color: "#0f766e" },
  });
  razorpay.open();
}

if (checkoutForm) {
  checkoutForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const user = loadUser() || getAuthData();
    if (!user?.email) {
      showStatus(paymentStatus, "Please create account or login before payment.", "error");
      userPanel?.scrollIntoView({ behavior: "smooth" });
      return;
    }
    const payment = Object.fromEntries(new FormData(checkoutForm).entries());
    const payload = paymentPayload(payment);
    try {
      if ((payment.paymentMethod || "").toLowerCase().includes("razorpay")) await startRazorpay(payload);
      else await completePayment(payload);
    } catch (error) {
      showStatus(paymentStatus, error.message, "error");
    }
  });
}

document.querySelectorAll("[data-buy-now]").forEach((button) => {
  button.addEventListener("click", (event) => {
    event.preventDefault();
    userPanel?.scrollIntoView({ behavior: "smooth" });
  });
});

