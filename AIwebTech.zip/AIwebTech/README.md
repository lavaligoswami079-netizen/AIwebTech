﻿# AIwebTech Project

This project is split clearly into frontend and backend.

## Folder structure

```text
AIwebTech/
  frontend/   website pages, styles, scripts, template layouts
  backend/    server/API code for templates, plans, contact, and Tace AI
```

## Run frontend

Open `frontend/index.html` with VS Code Live Server.

## Run backend

Open terminal inside `backend` and run:

```bash
npm start
```

Backend URL:

```text
http://localhost:5000
```
