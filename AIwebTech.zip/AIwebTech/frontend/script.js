﻿const API_BASE = window.AIWEBTECH_CONFIG?.API_BASE || "http://localhost:5000";
const filters = document.querySelectorAll(".filter");
const cards = document.querySelectorAll(".template-card");
const toast = document.querySelector("#toast");
const chatForm = document.querySelector("#chatForm");
const chatInput = document.querySelector("#chatInput");
const messages = document.querySelector("#messages");

function showToast(text) {
  toast.textContent = text;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 2800);
}

filters.forEach((button) => {
  button.addEventListener("click", () => {
    const filter = button.dataset.filter;
    filters.forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    cards.forEach((card) => {
      const isVisible = filter === "all" || card.dataset.category === filter;
      card.style.display = isVisible ? "block" : "none";
    });
  });
});

const templatePages = {
  "Agency Pro": "templates/agency-pro.html",
  "Smart Store": "templates/smart-store.html",
  "Restaurant Menu": "templates/restaurant-menu.html",
  "Edu Academy": "templates/edu-academy.html",
  "Health Clinic": "templates/health-clinic.html",
  "Real Estate": "templates/real-estate.html",
  "Creator Folio": "templates/creator-folio.html",
  "Travel Guide": "templates/travel-guide.html",
  "Beauty Studio": "templates/beauty-studio.html",
  "Tech Startup": "templates/tech-startup.html",
  "Nonprofit Cause": "templates/nonprofit-cause.html",
  "Event Launch": "templates/event-launch.html",
};

document.querySelectorAll("[data-template]").forEach((button) => {
  button.addEventListener("click", () => {
    const page = templatePages[button.dataset.template];
    if (page) {
      window.location.href = page;
      return;
    }
    showToast(`${button.dataset.template} preview selected.`);
  });
});


document.querySelectorAll("[data-buy]").forEach((button) => {
  button.addEventListener("click", () => {
    const selectedTemplate = document.querySelector("#selectedTemplate");
    if (selectedTemplate) selectedTemplate.value = button.dataset.buy;
    document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
    showToast(`${button.dataset.buy} selected. Fill the form to buy this website.`);
  });
});
document.querySelectorAll("[data-plan]").forEach((button) => {
  button.addEventListener("click", () => showToast(`${button.dataset.plan} plan selected. Add payment next.`));
});

document.querySelector(".contact-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const fields = form.querySelectorAll("input, select");
  const payload = {
    name: fields[0]?.value || "",
    email: fields[1]?.value || "",
    template: fields[2]?.value || "",
    plan: fields[3]?.value || "",
  };

  try {
    await fetch(`${API_BASE}/api/contact`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    showToast("Purchase request sent to backend.");
    form.reset();
  } catch (error) {
    showToast("Purchase request saved for the next step.");
  }
});

function addMessage(text, type) {
  const message = document.createElement("p");
  message.className = `message ${type}`;
  message.textContent = text;
  messages.appendChild(message);
  messages.scrollTop = messages.scrollHeight;
}

function aiReply(text) {
  const lower = text.toLowerCase();
  if (lower.includes("price") || lower.includes("plan")) {
    return "Starter is good for testing. Growth is best for selling templates. Business is best when you want a custom AI assistant.";
  }
  if (lower.includes("shop") || lower.includes("store")) {
    return "Smart Store is a strong choice. It is made for products, offers, and a checkout page.";
  }
  if (lower.includes("portfolio") || lower.includes("creative")) {
    return "Creator Folio is perfect for personal brands, students, designers, and artists.";
  }
  return "Tell me your business type, and I will suggest a template and plan for Ai web tace.";
}

async function getAiReply(text) {
  try {
    const response = await fetch(`${API_BASE}/api/ai-chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text }),
    });
    const data = await response.json();
    return data.reply || aiReply(text);
  } catch (error) {
    return aiReply(text);
  }
}

chatForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  addMessage(text, "user");
  chatInput.value = "";
  getAiReply(text).then((reply) => addMessage(reply, "ai"));
});




