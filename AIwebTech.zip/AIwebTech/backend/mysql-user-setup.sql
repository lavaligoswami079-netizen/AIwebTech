CREATE DATABASE IF NOT EXISTS aiwebtech;

CREATE USER IF NOT EXISTS 'aiwebtech_user'@'localhost' IDENTIFIED BY 'change_this_password';
GRANT ALL PRIVILEGES ON aiwebtech.* TO 'aiwebtech_user'@'localhost';
FLUSH PRIVILEGES;

USE aiwebtech;
SOURCE schema.sql;
